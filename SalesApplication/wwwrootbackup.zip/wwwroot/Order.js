﻿const apiUrl = "https://localhost:7141/api/orders"; // Your API base URL

// Show the order ID form
function showOrderIdForm() {
    document.getElementById("order-id-section").style.display = "block";
    document.getElementById("order-date-section").style.display = "none";
    document.getElementById("order-buttons").style.display = "none";
}

// Show the orders between dates form
function showOrderDateForm() {
    document.getElementById("order-date-section").style.display = "block";
    document.getElementById("order-id-section").style.display = "none";
    document.getElementById("order-buttons").style.display = "none";
}

// Display response message
function displayResponse(message) {
    document.getElementById("order-response").textContent = message;
}

// Logout function
function logout() {
    localStorage.removeItem("authToken");
    window.location.href = "/html/auth.html"; // Redirect to the login page after logout
}

// Fetch order details by Order ID
document.getElementById("order-id-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const orderId = document.getElementById("order-id").value;

    try {
        const token = localStorage.getItem("authToken");
        const response = await fetch(`${apiUrl}/shipdetails/${orderId}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            }
        });

        if (response.ok) {
            const orderData = await response.json();
            displayResponse(`Order Shipper Details: ${JSON.stringify(orderData)}`);
        } else {
            const error = await response.text();
            displayResponse(`Error: ${error}`);
        }
    } catch (error) {
        displayResponse(`Error: ${error.message}`);
    }
});

// Fetch orders between dates
document.getElementById("order-date-form")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const fromDate = document.getElementById("from-date").value;
    const toDate = document.getElementById("to-date").value;

    try {
        const token = localStorage.getItem("authToken");
        const response = await fetch(`${apiUrl}/BetweenDate/${fromDate}/${toDate}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            }
        });

        if (response.ok) {
            const orderData = await response.json();
            displayResponse(`Orders Between Dates: ${JSON.stringify(orderData)}`);
        } else {
            const error = await response.text();
            displayResponse(`Error: ${error}`);
        }
    } catch (error) {
        displayResponse(`Error: ${error.message}`);
    }
});

// Run the authorization check and adjust visibility on page load
window.addEventListener("load", () => {
    const logoutBtn = document.getElementById("logout-btn");
    const token = localStorage.getItem("authToken");

    if (token) {
        logoutBtn.style.display = "inline-block"; // Show logout button
    } else {
        logoutBtn.style.display = "none"; // Hide logout button
    }

    // Show the appropriate form based on the user's action
    document.getElementById("view-order-btn").addEventListener("click", showOrderIdForm);
    document.getElementById("view-orders-between-btn").addEventListener("click", showOrderDateForm);
});
