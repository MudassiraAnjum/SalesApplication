﻿// Base URL of the API
const baseUrl = "https://localhost:5001/api/Shipper";

// Display sections based on button clicks
document.getElementById("search-shipper-btn").addEventListener("click", () => {
    document.getElementById("shipper-search-section").style.display = "block";
    document.getElementById("total-earnings-section").style.display = "none";
});

document.getElementById("total-earnings-btn").addEventListener("click", () => {
    document.getElementById("shipper-search-section").style.display = "none";
    document.getElementById("total-earnings-section").style.display = "block";
});

// Search Shipper by Company Name
document.getElementById("shipper-search-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const companyName = document.getElementById("company-name").value.trim();
    const responseSection = document.getElementById("shipper-response");

    if (!companyName) {
        responseSection.innerHTML = "<p>Please enter a valid company name.</p>";
        return;
    }

    try {
        const response = await fetch(`${baseUrl}/${companyName}`, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token if needed
            },
        });

        if (!response.ok) {
            if (response.status === 404) {
                responseSection.innerHTML = "<p>Shipper not found.</p>";
            } else {
                throw new Error("Failed to fetch shipper details");
            }
            return;
        }

        const data = await response.json();
        responseSection.innerHTML = `
            <h3>Shipper Details</h3>
            <p><strong>Company Name:</strong> ${data.companyName}</p>
            <p><strong>Phone:</strong> ${data.phone}</p>
            <p><strong>Address:</strong> ${data.address}</p>
        `;
    } catch (error) {
        console.error("Error fetching shipper details:", error);
        responseSection.innerHTML = `<p>Error fetching shipper details. Please try again later.</p>`;
    }
});

// Get Total Earnings by Year
document.getElementById("total-earnings-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const year = document.getElementById("year").value.trim();
    const responseSection = document.getElementById("shipper-response");

    if (!year || isNaN(year)) {
        responseSection.innerHTML = "<p>Please enter a valid year.</p>";
        return;
    }

    try {
        const response = await fetch(`${baseUrl}/totalamountearnedbyshipper/${year}`, {
            headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token if needed
            },
        });

        if (!response.ok) {
            throw new Error("Failed to fetch earnings details");
        }

        const data = await response.json();
        responseSection.innerHTML = `
            <h3>Total Earnings</h3>
            <p><strong>Year:</strong> ${year}</p>
            <p><strong>Total Amount Earned:</strong> ${data.totalAmount}</p>
        `;
    } catch (error) {
        console.error("Error fetching earnings details:", error);
        responseSection.innerHTML = `<p>Error fetching earnings details. Please try again later.</p>`;
    }
});
