﻿document.addEventListener("DOMContentLoaded", () => {
    const updateForm = document.getElementById("update-territory-form");
    const territoryResponse = document.getElementById("territory-response");

    updateForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        // Fetch form values
        const territoryId = document.getElementById("territory-id").value.trim();
        const territoryName = document.getElementById("territory-name").value.trim();
        const territoryDescription = document.getElementById("territory-description").value.trim();

        // Request body
        const requestBody = {
            name: territoryName,
            description: territoryDescription,
        };

        try {
            // API request
            const response = await fetch(`/api/territory/update/${territoryId}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`, // Adjust token mechanism as necessary
                },
                body: JSON.stringify(requestBody),
            });

            if (response.ok) {
                const data = await response.json();
                territoryResponse.innerHTML = `
                    <p><strong>Territory Updated Successfully!</strong></p>
                    <p>ID: ${data.id}</p>
                    <p>Name: ${data.name}</p>
                    <p>Description: ${data.description}</p>
                `;
            } else {
                const errorData = await response.json();
                territoryResponse.innerHTML = `<p><strong>Error:</strong> ${errorData.message || "Failed to update territory."}</p>`;
            }
        } catch (error) {
            territoryResponse.innerHTML = `<p><strong>Error:</strong> ${error.message}</p>`;
        }
    });
});
