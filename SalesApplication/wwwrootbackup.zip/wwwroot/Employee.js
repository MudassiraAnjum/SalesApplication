﻿const apiUrl = "https://localhost:7141/api/Employee";
const token = localStorage.getItem("authToken");

// Ensure the token exists
if (!token) {
    alert("Authentication token missing. Please log in again.");
    window.location.href = "/Auth.html";
}

const headers = {
    "Authorization": `Bearer ${token}`,
    "Content-Type": "application/json"
};

// Function to toggle visibility of sections
function showSection(sectionId) {
    document.querySelectorAll("[id$='-section']").forEach(section => {
        section.style.display = section.id === sectionId ? "block" : "none";
    });
}

// Event listeners for navigation buttons
document.getElementById("get-employee-title").addEventListener("click", () => showSection("employee-title-section"));
document.getElementById("get-highest-sales-date").addEventListener("click", () => showSection("highest-sales-date-section"));
document.getElementById("get-highest-sales-year").addEventListener("click", () => showSection("highest-sales-year-section"));
document.getElementById("get-sales-by-employee").addEventListener("click", () => showSection("sales-by-employee-section"));

// Fetch Employees by Title
document.getElementById("search-title-btn").addEventListener("click", async () => {
    const title = document.getElementById("employee-title-input").value.trim();
    if (!title) {
        alert("Please enter a title.");
        return;
    }

    try {
        const response = await fetch(`${apiUrl}/title/${encodeURIComponent(title)}`, { method: "GET", headers });
        if (response.ok) {
            const employees = await response.json();
            document.getElementById("employee-title-list").innerHTML =
                employees.map(emp => `
<li>${emp.firstName} ${emp.lastName} (${emp.title})</li>`).join('');
        } else {
            alert("Error fetching employees by title.");
        }
    } catch (error) {
        console.error("Network error:", error);
        alert("Failed to fetch employees.");
    }
});

// Fetch Highest Sales by Date
document.getElementById("get-sales-by-date-btn").addEventListener("click", async () => {
    const date = document.getElementById("sales-date-input").value;
    if (!date) {
        alert("Please select a date.");
        return;
    }

    try {
        const response = await fetch(`${apiUrl}/highestsalebyemployee/${date}`, { method: "GET", headers });
        if (response.ok) {
            const sales = await response.json();
            document.getElementById("highest-sales-date-list").innerHTML =
                sales.map(sale => `
<li>${sale.employeeName} - ${sale.salesAmount}</li>`).join('');
        } else {
            alert("Error fetching sales by date.");
        }
    } catch (error) {
        console.error("Network error:", error);
        alert("Failed to fetch sales.");
    }
});

// Fetch Highest Sales by Year
document.getElementById("get-sales-by-year-btn").addEventListener("click", async () => {
    const year = document.getElementById("sales-year-input").value.trim();
    if (!year) {
        alert("Please enter a year.");
        return;
    }

    try {
        const response = await fetch(`${apiUrl}/highestsalebyemployee/${year}`, { method: "GET", headers });
        if (response.ok) {
            const sales = await response.json();
            document.getElementById("highest-sales-year-list").innerHTML =
                sales.map(sale => `
<li>${sale.employeeName} - ${sale.salesAmount}</li>`).join('');
        } else {
            alert("Error fetching sales by year.");
        }
    } catch (error) {
        console.error("Network error:", error);
        alert("Failed to fetch sales.");
    }
});

// Fetch Sales by Employee on a Date
document.getElementById("get-employee-sales-btn").addEventListener("click", async () => {
    const employeeId = document.getElementById("employee-id-input").value.trim();
    const date = document.getElementById("employee-sales-date-input").value;

    if (!employeeId || !date) {
        alert("Please enter Employee ID and date.");
        return;
    }

    try {
        const response = await fetch(`${apiUrl}/salemadebyanemployee/${employeeId}/${date}`, { method: "GET", headers });
        if (response.ok) {
            const sales = await response.json();
            document.getElementById("employee-sales-list").innerHTML =
                sales.map(sale => `
<li>Order ID: ${sale.orderId}, Total: ${sale.total}</li>`).join('');
        } else {
            alert("Error fetching sales by employee.");
        }
    } catch (error) {
        console.error("Network error:", error);
        alert("Failed to fetch sales.");
    }
});
